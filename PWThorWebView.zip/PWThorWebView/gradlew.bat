@rem
@rem  Gradle startup script for Windows
@rem
@if "%DEBUG%" == "" @echo off
gradle %*
