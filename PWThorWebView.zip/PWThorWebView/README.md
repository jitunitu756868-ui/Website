# PWThor - Android WebView APK Project

Generated with **PWThor: Web-to-Android APK Studio**.

## 📱 App Configuration
- **Application Name**: PWThor
- **Package Name**: `com.example.pwthorwebview`
- **Target URL**: [https://ais-pre-gee47wlqulxpfici3bo23f-97889722491.asia-southeast1.run.app](https://ais-pre-gee47wlqulxpfici3bo23f-97889722491.asia-southeast1.run.app)
- **Version**: 1.0.0 (Build 1)
- **Permissions Enabled**:
  - Internet & Network State
  - Camera & File Upload: `true`
  - Geolocation: `true`
  - Pull to Refresh: `true`
  - Offline Fallback: `true`
  - Back Key Intercept: `true`

---

## 🚀 How to Build the APK

### Option 1: ⚡ Automated Free Cloud Build (GitHub Actions)
1. Create a new GitHub repository (public or private).
2. Push or upload the unzipped files to your repository.
3. Open the **Actions** tab on your GitHub repository.
4. The workflow **"Build Android APK (PWThor)"** runs automatically.
5. In ~2 minutes, click on the completed run and download **`app-debug-apk`** directly to install on your Android device!

### Option 2: 💻 Using Android Studio (GUI)
1. Download & Install [Android Studio](https://developer.android.com/studio).
2. Open Android Studio -> Click **Open** -> Select this project folder.
3. Wait for Gradle sync to complete.
4. Click **Build** menu -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
5. Once built, click **locate** to get your `app-debug.apk`.

### Option 3: ⌨️ Command Line (CLI)
From the root of this project, run:

```bash
# On Linux/macOS
chmod +x gradlew
./gradlew assembleDebug

# On Windows
gradlew.bat assembleDebug
```

The generated APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 🔑 How to Generate a Signed Release APK for Google Play
1. Generate a keystore:
```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-alias
```
2. In Android Studio, go to **Build > Generate Signed Bundle / APK...** and follow the prompt using your keystore!
